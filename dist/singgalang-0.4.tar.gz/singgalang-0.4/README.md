<h1 align='center'>Harian Singgalang<br>sumber: <b><a href='https://hariansinggalang.co.id'>Hariansinggalang</a></b></h1>
<p>Python script dengan tempo yang sesingkat-singkatnya. <b>Padangpanjang Okt 26/2021</b></p>
<p>cuman pengen baca berita cepat, tanpa ribet kok.</p>
<hr><h3>install langsung dengan pip di Termux/Android</h3>
<p>sebelum install, gada salahnya untuk <b>upgrade</b> versi <b>pip</b> nya kan.</p>
<h3 align='center'>biasanya kalo di termux</h3>
<pre>pip install --upgrade pip</pre>
<hr><h3 align='center'>bisa juga gini</h3>
<pre>python3 -m pip install --upgrade pip</pre>
<hr><h3 align='center'>install</h3>
<blockquote>JohnDoe@localhost:~ pip install hariansinggalang<br>JohnDoe@localhost:~ singgalang</blockquote>
<hr><img src="./screenshot/Screenshot_2021-11-03_12-15-37.png">
<hr><h3 align="center">Serius Ini Deskripsi</h3>
<p>skrip ini adalah kodingan `buru-buru` yang saya langsung tulis ketika melihat modul <a href="https://pypi.org/project/pyhn">Pyhn - Python Hacker News</a> yang keren.</p>
<p>skrip ini berdasarkan implementasi dasar dari modul:</p>
<ul>
	<li><b>requests</b></li>
	<li><b>bs4 / BeautifulSoup</b></li>
	<li><b>urwid</b></li>
</ul>
<p>kontribusi dalam hal apa saja, sangat di terima. demi kemajuan dan kemakmuran seluruh rakyat Indonesia. <a href="https://t.me/ini_peninggi_badan">Telegram Saya</a></p>
